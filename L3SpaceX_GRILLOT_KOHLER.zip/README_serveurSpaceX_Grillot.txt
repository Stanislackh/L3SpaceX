Pour lancer le serveur il suffit de taper dans l'invite de commande:

python3 serveurSpaceX_Grillot.py

vous pouvez modifier l'adreese IP en modifiant la variable "addr" ligne 7
vous pouvez modifier le port d'écoute en modifiant la variable "port" ligne 8